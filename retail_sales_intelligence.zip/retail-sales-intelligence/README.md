# Retail Sales Intelligence System

An end-to-end data science project combining **SQL data warehousing**,
**machine learning**, and **Power BI** — built to demonstrate the full
workflow a data analyst/scientist role actually requires, not just a
model in a notebook.

> Raw data → SQL star-schema warehouse → advanced SQL analytics →
> 3 ML models (forecasting, churn, segmentation) → predictions written
> back to SQL → Power BI dashboard.

See [`docs/architecture.md`](docs/architecture.md) for the full diagram.

## What's inside

| Layer | What it does | Where |
|---|---|---|
| **Data generation** | Synthetic 3-year retail dataset (2,000 customers, 60 products, 12 stores, ~78K transactions) with realistic seasonality, promotions, and customer churn lifecycles | `data/generate_data.py` |
| **SQL warehouse** | Star schema (fact_sales + 4 dimensions), ETL cleaning/dedup, indexes | `sql/schema/`, `sql/etl/` |
| **SQL analytics** | Window functions, CTEs, YoY/MoM growth, top-N rankings, reusable views | `sql/analytics/` |
| **ML: Forecasting** | 90-day sales forecast, XGBoost on lag/rolling/calendar features, recursive multi-step prediction | `python/forecasting/` |
| **ML: Churn** | Customer churn classifier, leakage-safe feature engineering, feature-importance ranking | `python/churn_model/` |
| **ML: Segmentation** | RFM analysis refined with K-Means, business-readable segment labels | `python/segmentation/` |
| **Power BI** | Connection guide, DAX measure library, CSV export script | `powerbi/` |
| **Tests** | 9 tests covering data integrity, referential integrity, and model output sanity | `tests/` |
| **CI/CD** | GitHub Actions runs the full pipeline + tests on every push | `.github/workflows/ci.yml` |
| **Docker** | One-command containerized run | `Dockerfile` |

## Quickstart

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Run the entire pipeline (data gen -> warehouse -> ML -> Power BI exports)
python run_pipeline.py

# 3. Run tests
pytest tests/ -v
```

Or with Docker:

```bash
docker build -t retail-intelligence .
docker run --rm -v $(pwd)/data:/app/data -v $(pwd)/powerbi/exports:/app/powerbi/exports retail-intelligence
```

This produces:
- `data/warehouse.db` — the full SQLite star-schema warehouse
- `powerbi/exports/*.csv` — every table ready for Power BI import
- Console output with model metrics (forecast MAPE, churn AUC, segment summary)

## Results (on the synthetic dataset)

- **Forecast model:** ~10-14% MAPE on a 60-day backtest
- **Churn model:** ~0.93 AUC, 85%+ recall on the churned class
- **Segmentation:** 6 business-readable RFM segments (Champions, Loyal Customers, At Risk, Lost, New/Low Engagement, Needs Attention)

## Connecting Power BI

See [`powerbi/POWERBI_GUIDE.md`](powerbi/POWERBI_GUIDE.md) for full
instructions, DAX measures, and suggested dashboard pages. Fastest path:
run `python powerbi/export_for_powerbi.py` and import the CSVs directly.

## Example SQL (see `sql/analytics/queries.sql` for the full set)

```sql
-- Top 3 products per store by revenue
WITH product_store_sales AS (
    SELECT s.store_name, p.product_name, SUM(f.sales_amount) AS total_sales,
           RANK() OVER (PARTITION BY s.store_name ORDER BY SUM(f.sales_amount) DESC) AS sales_rank
    FROM fact_sales f
    JOIN dim_store s ON f.store_key = s.store_key
    JOIN dim_product p ON f.product_key = p.product_key
    GROUP BY s.store_name, p.product_name
)
SELECT * FROM product_store_sales WHERE sales_rank <= 3;
```

## Project structure

```
retail-sales-intelligence/
├── data/
│   ├── generate_data.py       # synthetic data generator
│   └── raw/                   # generated CSVs (gitignored)
├── sql/
│   ├── schema/create_schema.sql
│   ├── etl/load_data.py
│   └── analytics/queries.sql, create_views.sql
├── python/
│   ├── db_connector.py
│   ├── forecasting/train_forecast.py
│   ├── churn_model/train_churn.py
│   └── segmentation/rfm_segmentation.py
├── powerbi/
│   ├── POWERBI_GUIDE.md
│   └── export_for_powerbi.py
├── docs/
│   └── architecture.md
├── tests/
│   └── test_pipeline.py
├── .github/workflows/ci.yml
├── Dockerfile
├── requirements.txt
└── run_pipeline.py
```

## Notes for interviews

- The dataset is **synthetic but realistic** — it has intentional messiness
  (nulls, duplicate rows, bad quantities) so the ETL/cleaning work is real,
  and customer purchase lifecycles are modeled (not uniform random) so the
  churn model has genuine signal to learn from.
- The churn model's features are built **strictly from data before the
  churn-determination cutoff** — a deliberate choice to avoid label leakage,
  worth mentioning explicitly in interviews.
- Predictions are written back to SQL tables rather than kept in
  pickled model files — this is what makes the Power BI layer possible
  without any custom connector.
- Swap `python/db_connector.py`'s connection to point at SQL Server or
  Postgres to turn this into a "real" deployment; nothing else changes.
