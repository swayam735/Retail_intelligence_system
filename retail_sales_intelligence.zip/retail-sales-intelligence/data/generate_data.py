"""
generate_data.py
-----------------
Generates a realistic synthetic retail dataset (no external download needed)
so the whole pipeline runs end-to-end out of the box.

Produces 4 raw CSVs under data/raw/:
    customers.csv
    products.csv
    stores.csv
    sales.csv   (transaction-level, ~3 years of daily sales)

Data has intentional real-world messiness (nulls, duplicates, outliers)
so the SQL/ETL layer has real cleaning work to do.
"""

import numpy as np
import pandas as pd
from pathlib import Path
from datetime import datetime, timedelta

RNG = np.random.default_rng(42)
OUT_DIR = Path(__file__).parent / "raw"
OUT_DIR.mkdir(parents=True, exist_ok=True)

N_CUSTOMERS = 2000
N_PRODUCTS = 60
N_STORES = 12
START_DATE = datetime(2022, 1, 1)
END_DATE = datetime(2024, 12, 31)

CATEGORIES = ["Electronics", "Grocery", "Apparel", "Home & Living", "Beauty", "Sports"]
REGIONS = ["North", "South", "East", "West", "Central"]
CITIES = {
    "North": ["Delhi", "Chandigarh", "Lucknow"],
    "South": ["Bengaluru", "Chennai", "Hyderabad"],
    "East": ["Kolkata", "Bhubaneswar"],
    "West": ["Mumbai", "Pune", "Ahmedabad"],
    "Central": ["Bhopal", "Indore", "Nagpur"],
}


def gen_customers(n):
    span_days = (END_DATE - START_DATE).days
    offsets = RNG.integers(0, span_days, n)
    signup_dates = pd.to_datetime([START_DATE + timedelta(days=int(o)) for o in offsets])
    df = pd.DataFrame({
        "customer_id": range(1, n + 1),
        "customer_name": [f"Customer_{i}" for i in range(1, n + 1)],
        "signup_date": signup_dates,
        "region": RNG.choice(REGIONS, n),
        "age": RNG.integers(18, 70, n),
    })
    # inject some messiness: a few null ages, a few duplicate customer rows
    df.loc[RNG.choice(df.index, 30, replace=False), "age"] = np.nan
    dupes = df.sample(15, random_state=1)
    df = pd.concat([df, dupes], ignore_index=True)
    return df


def gen_products(n):
    cats = RNG.choice(CATEGORIES, n)
    base_price = RNG.uniform(5, 500, n).round(2)
    df = pd.DataFrame({
        "product_id": range(1, n + 1),
        "product_name": [f"Product_{i}" for i in range(1, n + 1)],
        "category": cats,
        "unit_cost": (base_price * RNG.uniform(0.4, 0.7, n)).round(2),
        "unit_price": base_price,
    })
    return df


def gen_stores(n):
    regions = RNG.choice(REGIONS, n)
    cities = [RNG.choice(CITIES[r]) for r in regions]
    df = pd.DataFrame({
        "store_id": range(1, n + 1),
        "store_name": [f"Store_{i}" for i in range(1, n + 1)],
        "region": regions,
        "city": cities,
    })
    return df


def seasonal_multiplier(date):
    # yearly seasonality (festive Q4 bump, summer dip) + weekly seasonality
    day_of_year = date.timetuple().tm_yday
    yearly = 1 + 0.35 * np.sin(2 * np.pi * (day_of_year - 260) / 365)  # peak ~ Oct-Nov
    weekday = date.weekday()
    weekly = 1.25 if weekday >= 5 else 1.0  # weekend bump
    return yearly * weekly


def gen_customer_lifecycles(customers):
    """
    Give each customer a realistic lifecycle instead of uniform random
    activity: a signup point, an activity level, and - for a meaningful
    chunk of customers - a "went dormant" point before END_DATE so the
    churn model has real signal to learn from.
    """
    n = len(customers)
    total_days = (END_DATE - START_DATE).days

    lifecycle = pd.DataFrame({"customer_id": customers["customer_id"].values})
    # activity weight: how often this customer buys relative to others (power law)
    lifecycle["activity_weight"] = RNG.pareto(2.5, n) + 0.3

    # ~35% of customers churn (stop buying) at some point before the end date
    churns = RNG.random(n) < 0.35
    churn_day_offset = RNG.integers(int(total_days * 0.3), total_days, n)
    lifecycle["active_until_day"] = np.where(churns, churn_day_offset, total_days)
    return lifecycle.set_index("customer_id")


def gen_sales(customers, products, stores):
    dates = pd.date_range(START_DATE, END_DATE, freq="D")
    rows = []
    trend_growth = np.linspace(1.0, 1.4, len(dates))  # slow YoY growth trend

    lifecycles = gen_customer_lifecycles(customers)
    cust_ids_all = lifecycles.index.values
    weights_all = lifecycles["activity_weight"].values
    active_until_all = lifecycles["active_until_day"].values

    prod_ids = products["product_id"].values
    store_ids = stores["store_id"].values

    for i, date in enumerate(dates):
        mult = seasonal_multiplier(date) * trend_growth[i]
        n_transactions = int(RNG.poisson(lam=55 * mult))
        if n_transactions == 0:
            continue

        # only customers still "active" on this day are eligible to purchase
        eligible_mask = active_until_all >= i
        eligible_ids = cust_ids_all[eligible_mask]
        eligible_weights = weights_all[eligible_mask]
        eligible_weights = eligible_weights / eligible_weights.sum()

        cust_sample = RNG.choice(eligible_ids, n_transactions, p=eligible_weights)
        prod_sample = RNG.choice(prod_ids, n_transactions)
        store_sample = RNG.choice(store_ids, n_transactions)
        qty = RNG.integers(1, 6, n_transactions)
        promo_flag = RNG.random(n_transactions) < 0.12

        for c, p, s, q, promo in zip(cust_sample, prod_sample, store_sample, qty, promo_flag):
            rows.append((date, c, p, s, q, promo))

    df = pd.DataFrame(rows, columns=["order_date", "customer_id", "product_id", "store_id", "quantity", "promo_flag"])
    df.insert(0, "order_id", range(1, len(df) + 1))

    price_map = products.set_index("product_id")["unit_price"]
    df["unit_price"] = df["product_id"].map(price_map)
    df["discount_pct"] = np.where(df["promo_flag"], RNG.uniform(0.05, 0.30, len(df)).round(2), 0.0)
    df["sales_amount"] = (df["quantity"] * df["unit_price"] * (1 - df["discount_pct"])).round(2)

    # inject messiness: some negative/null quantities (returns / bad data), some duplicate order_ids
    bad_idx = RNG.choice(df.index, 40, replace=False)
    df.loc[bad_idx[:20], "quantity"] = -df.loc[bad_idx[:20], "quantity"]
    df.loc[bad_idx[20:], "sales_amount"] = np.nan
    dupes = df.sample(25, random_state=2)
    df = pd.concat([df, dupes], ignore_index=True)

    return df


def main():
    customers = gen_customers(N_CUSTOMERS)
    products = gen_products(N_PRODUCTS)
    stores = gen_stores(N_STORES)
    sales = gen_sales(customers, products, stores)

    customers.to_csv(OUT_DIR / "customers.csv", index=False)
    products.to_csv(OUT_DIR / "products.csv", index=False)
    stores.to_csv(OUT_DIR / "stores.csv", index=False)
    sales.to_csv(OUT_DIR / "sales.csv", index=False)

    print(f"customers: {len(customers):,} rows")
    print(f"products:  {len(products):,} rows")
    print(f"stores:    {len(stores):,} rows")
    print(f"sales:     {len(sales):,} rows")
    print(f"\nRaw CSVs written to: {OUT_DIR}")


if __name__ == "__main__":
    main()
