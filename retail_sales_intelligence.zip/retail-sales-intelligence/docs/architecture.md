# Architecture

```mermaid
flowchart TD
    A[Synthetic Data Generator<br/>data/generate_data.py] --> B[(Raw CSVs<br/>customers, products, stores, sales)]
    B --> C[ETL Layer<br/>sql/etl/load_data.py<br/>cleaning, dedup, validation]
    C --> D[(SQL Warehouse<br/>Star Schema<br/>fact_sales + 4 dims)]
    D --> E[Analytical SQL<br/>window fns, CTEs, views]
    D --> F[Sales Forecasting<br/>XGBoost on lag features]
    D --> G[Churn Classification<br/>XGBoost + leakage-safe labels]
    D --> H[RFM Segmentation<br/>K-Means clustering]
    F --> I[(ml_sales_forecast)]
    G --> J[(ml_customer_churn)]
    H --> K[(ml_customer_segments)]
    I --> D
    J --> D
    K --> D
    D --> L[Power BI<br/>Executive / Forecast / Customer / Product pages]
    E --> L
```

## Data flow summary

1. **Generate** — synthetic 3-year retail dataset with realistic seasonality, trend, promotions, and customer churn lifecycles (intentionally messy: nulls, duplicates, bad rows)
2. **Load** — Python ETL cleans the raw data and loads it into a SQLite star schema (fact_sales + dim_date/customer/product/store)
3. **Analyze** — SQL layer provides window-function analytics (running totals, YoY, rankings) and reusable views
4. **Model** — three ML models read from SQL, train, and write predictions back to SQL:
   - Sales forecast (next 90 days, XGBoost on lag/rolling/calendar features)
   - Customer churn (leakage-safe features, XGBoost classifier)
   - RFM customer segmentation (K-Means + business labels)
5. **Visualize** — Power BI connects directly to the warehouse (or CSV exports) to build the dashboard

## Why this design

- **SQL does the heavy structural work** (schema, cleaning, aggregation) — not pandas doing everything, which is what most portfolio projects get wrong
- **Predictions live in SQL tables**, not pickled model files — any BI tool or downstream consumer can use them without touching Python
- **No leakage in the churn model** — features are built strictly from history before the churn-determination cutoff
- **SQLite for portability** — the whole thing runs with zero external services; swap `python/db_connector.py` for SQL Server/Postgres in one line for a "real" deployment
