# Power BI Layer

This project's warehouse (`data/warehouse.db`, SQLite) plus the three ML
output tables are meant to be consumed **directly by Power BI** - that's
the point of writing predictions back to SQL instead of leaving them in a
notebook.

## 1. Connecting Power BI to the warehouse

SQLite has no native Power BI connector, so use one of these (pick based
on what you have installed):

**Option A - ODBC (recommended for a real demo)**
1. Install the SQLite ODBC driver (`sqliteodbc`).
2. In Windows ODBC Data Source Administrator, create a System DSN pointing
   at `data/warehouse.db`.
3. Power BI Desktop → Get Data → ODBC → select the DSN → pick the tables
   below.

**Option B - Export to CSV/Parquet (fastest, zero extra installs)**
Run `python powerbi/export_for_powerbi.py` (included) - it exports every
table Power BI needs as clean CSVs into `powerbi/exports/`. Get Data →
Folder, or import each CSV individually. This is the simplest path if
you just need a working `.pbix` for your portfolio.

**Option C - Migrate to SQL Server / Postgres**
For a resume-ready "real" setup, point `python/db_connector.py` at a
SQL Server or Postgres instance instead of SQLite (one line change) and
use Power BI's native SQL Server connector with DirectQuery, so the
dashboard always reflects the latest data without a manual refresh step.

## 2. Tables/views to load into Power BI

| Table | Purpose |
|---|---|
| `fact_sales` | Transaction grain, the core fact table |
| `dim_date`, `dim_customer`, `dim_product`, `dim_store` | Dimensions - build relationships in Power BI's Model view exactly like the star schema |
| `vw_monthly_kpi_summary` | Pre-aggregated monthly KPIs (orders, revenue, AOV, promo revenue) |
| `ml_sales_forecast` | Forecast vs. actual chart data |
| `ml_customer_churn` | Churn risk band per customer |
| `ml_customer_segments` | RFM segment per customer |

Build relationships: `fact_sales[date_key] -> dim_date[date_key]`, etc.
(standard star schema - one-to-many from dimension to fact).

## 3. Suggested dashboard pages

1. **Executive Overview** - total revenue, orders, AOV KPI cards; monthly
   trend line; region breakdown map/bar.
2. **Sales Forecast** - actual sales line + `ml_sales_forecast` predicted
   line with `lower_bound`/`upper_bound` as a shaded confidence band.
3. **Customer Analytics** - churn risk band distribution, RFM segment
   treemap, drill-through to an individual customer's order history.
4. **Product Performance** - top products/categories by revenue and
   margin, promo lift analysis (promo vs non-promo average order value).

## 4. DAX measures to include (paste into a "Measures" table in Power BI)

```dax
Total Revenue = SUM(fact_sales[sales_amount])

Total Orders = DISTINCTCOUNT(fact_sales[order_id])

Average Order Value = DIVIDE([Total Revenue], [Total Orders])

Prior Month Revenue =
CALCULATE([Total Revenue], DATEADD(dim_date[full_date], -1, MONTH))

MoM Revenue Growth % =
DIVIDE([Total Revenue] - [Prior Month Revenue], [Prior Month Revenue])

Prior Year Revenue =
CALCULATE([Total Revenue], SAMEPERIODLASTYEAR(dim_date[full_date]))

YoY Revenue Growth % =
DIVIDE([Total Revenue] - [Prior Year Revenue], [Prior Year Revenue])

Rolling 7-Day Revenue =
CALCULATE(
    [Total Revenue],
    DATESINPERIOD(dim_date[full_date], MAX(dim_date[full_date]), -7, DAY)
)

Promo Revenue Share % =
DIVIDE(
    CALCULATE([Total Revenue], fact_sales[promo_flag] = 1),
    [Total Revenue]
)

High Risk Customers = 
CALCULATE(DISTINCTCOUNT(ml_customer_churn[customer_id]), ml_customer_churn[churn_risk_band] = "High")

Forecast Accuracy (MAPE-style) =
AVERAGEX(
    ml_sales_forecast,
    DIVIDE(ABS(ml_sales_forecast[predicted_sales] - [Total Revenue]), [Total Revenue])
)
```

## 5. Walkthrough video

Record a 2-3 minute screen capture clicking through the slicers and
drill-throughs, export as a GIF, and embed it near the top of your
README - most reviewers will never open the `.pbix` file themselves.
