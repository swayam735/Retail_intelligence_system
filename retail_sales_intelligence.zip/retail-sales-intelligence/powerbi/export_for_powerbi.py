"""
export_for_powerbi.py
----------------------
Exports every table Power BI needs as a clean CSV, so you can build the
dashboard with Get Data -> Folder even without an ODBC driver installed.

Usage:
    python powerbi/export_for_powerbi.py
"""

import sys
import logging
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parents[1] / "python"))
from db_connector import read_query  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
log = logging.getLogger("export")

OUT_DIR = Path(__file__).parent / "exports"

TABLES = [
    "fact_sales", "dim_date", "dim_customer", "dim_product", "dim_store",
    "vw_monthly_kpi_summary", "ml_sales_forecast", "ml_customer_churn", "ml_customer_segments",
]


def main():
    OUT_DIR.mkdir(exist_ok=True)
    for table in TABLES:
        df = read_query(f"SELECT * FROM {table}")
        out_path = OUT_DIR / f"{table}.csv"
        df.to_csv(out_path, index=False)
        log.info("Exported %s (%d rows) -> %s", table, len(df), out_path)
    log.info("Done. In Power BI: Get Data -> Folder -> %s", OUT_DIR)


if __name__ == "__main__":
    main()
