"""
train_churn.py
---------------
Defines churn as: a customer who has NOT purchased in the last 90 days
(relative to the dataset's max date), and trains a classifier to predict
churn probability from behavioral features known BEFORE that cutoff -
avoiding label leakage.

Writes customer_id, churn_probability, churn_risk_band to ml_customer_churn.
"""

import sys
import logging
from pathlib import Path

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score, classification_report
import xgboost as xgb

sys.path.append(str(Path(__file__).resolve().parents[1]))
from db_connector import read_query, write_table  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
log = logging.getLogger("churn")

CHURN_WINDOW_DAYS = 90
FEATURE_CUTOFF_DAYS = 90  # only use behavior from before this window to build features


def load_customer_orders() -> pd.DataFrame:
    query = """
        SELECT
            c.customer_id, c.age, c.region, c.signup_date,
            d.full_date AS order_date, f.sales_amount, f.discount_pct, p.category
        FROM fact_sales f
        JOIN dim_customer c ON f.customer_key = c.customer_key
        JOIN dim_date d ON f.date_key = d.date_key
        JOIN dim_product p ON f.product_key = p.product_key
    """
    df = read_query(query)
    df["order_date"] = pd.to_datetime(df["order_date"])
    df["signup_date"] = pd.to_datetime(df["signup_date"])
    return df


def build_features_and_labels(df: pd.DataFrame):
    max_date = df["order_date"].max()
    churn_cutoff = max_date - pd.Timedelta(days=CHURN_WINDOW_DAYS)
    feature_cutoff = churn_cutoff - pd.Timedelta(days=FEATURE_CUTOFF_DAYS)

    # Label: did the customer place any order in the last CHURN_WINDOW_DAYS?
    recent_orders = df[df["order_date"] > churn_cutoff]
    active_customers = set(recent_orders["customer_id"].unique())

    # Features: built ONLY from history before churn_cutoff (no leakage)
    hist = df[df["order_date"] <= churn_cutoff]

    agg = hist.groupby("customer_id").agg(
        total_orders=("order_date", "count"),
        total_spend=("sales_amount", "sum"),
        avg_order_value=("sales_amount", "mean"),
        avg_discount_used=("discount_pct", "mean"),
        n_categories=("category", "nunique"),
        first_order=("order_date", "min"),
        last_order=("order_date", "max"),
    ).reset_index()

    agg["recency_days"] = (churn_cutoff - agg["last_order"]).dt.days
    agg["tenure_days"] = (churn_cutoff - agg["first_order"]).dt.days
    agg["order_frequency"] = agg["total_orders"] / agg["tenure_days"].clip(lower=1)

    meta = df[["customer_id", "age", "region"]].drop_duplicates("customer_id")
    agg = agg.merge(meta, on="customer_id", how="left")

    agg["churned"] = (~agg["customer_id"].isin(active_customers)).astype(int)

    agg = pd.get_dummies(agg, columns=["region"], prefix="region")
    return agg


def main():
    log.info("Loading order history...")
    df = load_customer_orders()
    features_df = build_features_and_labels(df)

    drop_cols = ["customer_id", "first_order", "last_order", "churned"]
    feature_cols = [c for c in features_df.columns if c not in drop_cols]

    X = features_df[feature_cols].fillna(0)
    y = features_df["churned"]

    log.info("Churn rate in dataset: %.1f%%", y.mean() * 100)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )

    model = xgb.XGBClassifier(
        n_estimators=200, max_depth=4, learning_rate=0.05,
        subsample=0.8, colsample_bytree=0.8, eval_metric="logloss", random_state=42
    )
    model.fit(X_train, y_train)

    test_probs = model.predict_proba(X_test)[:, 1]
    auc = roc_auc_score(y_test, test_probs)
    log.info("Test AUC: %.3f", auc)
    log.info("\n%s", classification_report(y_test, model.predict(X_test)))

    # Feature importance (SHAP-style ranking without the heavy shap dependency;
    # swap in real `shap.TreeExplainer` in a full build for per-prediction explanations)
    importances = pd.Series(model.feature_importances_, index=feature_cols).sort_values(ascending=False)
    log.info("Top 5 churn drivers:\n%s", importances.head(5).to_string())

    # Score ALL customers for the output table
    all_probs = model.predict_proba(X)[:, 1]
    result = pd.DataFrame({
        "customer_id": features_df["customer_id"],
        "churn_probability": all_probs.round(4),
    })
    result["churn_risk_band"] = pd.cut(
        result["churn_probability"], bins=[-0.01, 0.33, 0.66, 1.0],
        labels=["Low", "Medium", "High"]
    )
    result["model_name"] = f"xgboost_churn_v1 (AUC={auc:.3f})"

    write_table(result, "ml_customer_churn", if_exists="replace")
    log.info("Wrote %d customer churn scores to ml_customer_churn", len(result))


if __name__ == "__main__":
    main()
