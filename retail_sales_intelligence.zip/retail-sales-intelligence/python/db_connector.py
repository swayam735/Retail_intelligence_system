"""
db_connector.py
----------------
Single shared utility so every ML script reads from / writes to the same
SQLite warehouse the same way. Swap this file's connection string to point
at SQL Server/Postgres in a real deployment - nothing else needs to change.
"""

import sqlite3
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "data" / "warehouse.db"


def get_connection():
    return sqlite3.connect(DB_PATH)


def read_query(query: str) -> pd.DataFrame:
    with get_connection() as conn:
        return pd.read_sql(query, conn)


def write_table(df: pd.DataFrame, table_name: str, if_exists: str = "replace"):
    with get_connection() as conn:
        df.to_sql(table_name, conn, if_exists=if_exists, index=False)
