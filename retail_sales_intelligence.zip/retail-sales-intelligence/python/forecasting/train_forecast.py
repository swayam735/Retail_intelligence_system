"""
train_forecast.py
------------------
Forecasts daily total sales for the next 90 days.

Approach: gradient-boosted trees (XGBoost) on lag + rolling + calendar
features, trained on the SQL warehouse's fact_sales, with the forecast
written back to ml_sales_forecast so Power BI can plot actual vs. predicted
directly from the database.

We deliberately avoid Prophet here to keep the environment install-friendly
(no compiled Stan dependency) - XGBoost on engineered lag features is a
standard, production-grade approach for this problem and is easy to explain
in an interview.
"""

import sys
import logging
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_percentage_error, mean_absolute_error
import xgboost as xgb

sys.path.append(str(Path(__file__).resolve().parents[1]))
from db_connector import read_query, write_table  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
log = logging.getLogger("forecast")

FORECAST_HORIZON = 90
N_LAGS = 14


def load_daily_sales() -> pd.DataFrame:
    query = """
        SELECT d.full_date AS order_date, SUM(f.sales_amount) AS total_sales
        FROM fact_sales f
        JOIN dim_date d ON f.date_key = d.date_key
        GROUP BY d.full_date
        ORDER BY d.full_date
    """
    df = read_query(query)
    df["order_date"] = pd.to_datetime(df["order_date"])
    return df.set_index("order_date").asfreq("D").fillna(0.0)


def make_features(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    for lag in range(1, N_LAGS + 1):
        out[f"lag_{lag}"] = out["total_sales"].shift(lag)
    out["rolling_mean_7"] = out["total_sales"].shift(1).rolling(7).mean()
    out["rolling_mean_30"] = out["total_sales"].shift(1).rolling(30).mean()
    out["rolling_std_7"] = out["total_sales"].shift(1).rolling(7).std()
    out["day_of_week"] = out.index.dayofweek
    out["month"] = out.index.month
    out["day_of_year"] = out.index.dayofyear
    out["is_weekend"] = (out.index.dayofweek >= 5).astype(int)
    return out


def train_test_split_ts(df: pd.DataFrame, test_days=60):
    return df.iloc[:-test_days], df.iloc[-test_days:]


def evaluate(model, feature_cols, test_df):
    preds = model.predict(test_df[feature_cols])
    mape = mean_absolute_percentage_error(test_df["total_sales"], preds)
    mae = mean_absolute_error(test_df["total_sales"], preds)
    log.info("Backtest MAPE: %.2f%% | MAE: %.2f", mape * 100, mae)
    return mape, mae


def recursive_forecast(model, feature_cols, history: pd.Series, horizon: int) -> pd.DataFrame:
    """Forecast step by step, feeding each prediction back in as a new lag."""
    series = history.copy()
    future_dates = pd.date_range(series.index[-1] + pd.Timedelta(days=1), periods=horizon, freq="D")
    preds = []

    for date in future_dates:
        row = {}
        for lag in range(1, N_LAGS + 1):
            row[f"lag_{lag}"] = series.iloc[-lag]
        row["rolling_mean_7"] = series.iloc[-7:].mean()
        row["rolling_mean_30"] = series.iloc[-30:].mean()
        row["rolling_std_7"] = series.iloc[-7:].std()
        row["day_of_week"] = date.dayofweek
        row["month"] = date.month
        row["day_of_year"] = date.dayofyear
        row["is_weekend"] = int(date.dayofweek >= 5)

        X = pd.DataFrame([row])[feature_cols]
        pred = max(0.0, float(model.predict(X)[0]))
        preds.append((date, pred))
        series.loc[date] = pred

    return pd.DataFrame(preds, columns=["forecast_date", "predicted_sales"])


def main():
    log.info("Loading daily sales from warehouse...")
    daily = load_daily_sales()

    featured = make_features(daily).dropna()
    feature_cols = [c for c in featured.columns if c != "total_sales"]

    train_df, test_df = train_test_split_ts(featured, test_days=60)

    model = xgb.XGBRegressor(
        n_estimators=400, max_depth=5, learning_rate=0.03,
        subsample=0.8, colsample_bytree=0.8, random_state=42
    )
    model.fit(train_df[feature_cols], train_df["total_sales"])

    mape, mae = evaluate(model, feature_cols, test_df)

    # Retrain on full history before forecasting forward
    model.fit(featured[feature_cols], featured["total_sales"])
    forecast_df = recursive_forecast(model, feature_cols, daily["total_sales"], FORECAST_HORIZON)

    # crude but honest uncertainty band from backtest residual std
    residual_std = np.std(test_df["total_sales"].values - model.predict(test_df[feature_cols]))
    forecast_df["lower_bound"] = (forecast_df["predicted_sales"] - 1.28 * residual_std).clip(lower=0)
    forecast_df["upper_bound"] = forecast_df["predicted_sales"] + 1.28 * residual_std
    forecast_df["model_name"] = f"xgboost_v1 (backtest MAPE={mape:.2%})"

    write_table(forecast_df, "ml_sales_forecast", if_exists="replace")
    log.info("Wrote %d forecast rows to ml_sales_forecast", len(forecast_df))
    log.info("Sample forecast:\n%s", forecast_df.head(5).to_string(index=False))


if __name__ == "__main__":
    main()
