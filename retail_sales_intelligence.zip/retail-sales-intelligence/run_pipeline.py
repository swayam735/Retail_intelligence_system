"""
run_pipeline.py
----------------
Runs the full project end-to-end, in order:
    1. Generate synthetic raw data
    2. Build the SQL warehouse (schema + ETL)
    3. Create analytical views
    4. Train & write the 3 ML models' predictions back to SQL
    5. Export flattened tables for Power BI

Usage:
    python run_pipeline.py
"""

import logging
import sqlite3
import subprocess
import sys
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
log = logging.getLogger("pipeline")

ROOT = Path(__file__).parent
DB_PATH = ROOT / "data" / "warehouse.db"
VIEWS_SQL = ROOT / "sql" / "analytics" / "create_views.sql"

STEPS = [
    ("Generating synthetic raw data", ["python3", "data/generate_data.py"]),
    ("Building SQL warehouse (schema + ETL)", ["python3", "sql/etl/load_data.py"]),
    ("Training sales forecast model", ["python3", "python/forecasting/train_forecast.py"]),
    ("Training churn classification model", ["python3", "python/churn_model/train_churn.py"]),
    ("Running RFM customer segmentation", ["python3", "python/segmentation/rfm_segmentation.py"]),
    ("Exporting tables for Power BI", ["python3", "powerbi/export_for_powerbi.py"]),
]


def create_views():
    log.info("STEP | Creating analytical views")
    conn = sqlite3.connect(DB_PATH)
    conn.executescript(VIEWS_SQL.read_text())
    conn.commit()
    conn.close()


def run_step(name, cmd):
    log.info("STEP | %s", name)
    result = subprocess.run(cmd, cwd=ROOT)
    if result.returncode != 0:
        log.error("Step failed: %s", name)
        sys.exit(1)


def main():
    for i, (name, cmd) in enumerate(STEPS, 1):
        run_step(f"[{i}/{len(STEPS)}] {name}", cmd)
        if name.startswith("Building SQL warehouse"):
            create_views()
    log.info("Pipeline complete. Warehouse: %s | CSVs: powerbi/exports/", DB_PATH)


if __name__ == "__main__":
    main()
