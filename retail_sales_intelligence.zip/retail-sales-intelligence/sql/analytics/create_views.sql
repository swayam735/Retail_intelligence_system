-- =====================================================================
-- create_views.sql
-- Reusable views, run after the warehouse is loaded.
-- In SQL Server, vw_monthly_kpi_summary would instead be a stored
-- procedure (CREATE PROCEDURE sp_monthly_summary AS ...).
-- =====================================================================

DROP VIEW IF EXISTS vw_monthly_kpi_summary;
CREATE VIEW vw_monthly_kpi_summary AS
SELECT
    d.year,
    d.month,
    d.month_name,
    COUNT(DISTINCT f.order_id) AS orders,
    SUM(f.sales_amount) AS revenue,
    ROUND(AVG(f.sales_amount), 2) AS avg_order_value,
    SUM(CASE WHEN f.promo_flag = 1 THEN f.sales_amount ELSE 0 END) AS promo_revenue
FROM fact_sales f
JOIN dim_date d ON f.date_key = d.date_key
GROUP BY d.year, d.month, d.month_name;

DROP VIEW IF EXISTS vw_customer_360;
CREATE VIEW vw_customer_360 AS
SELECT
    c.customer_id, c.customer_name, c.region, c.age_band,
    ch.churn_probability, ch.churn_risk_band,
    sg.rfm_segment, sg.recency_days, sg.frequency, sg.monetary
FROM dim_customer c
LEFT JOIN ml_customer_churn ch ON c.customer_id = ch.customer_id
LEFT JOIN ml_customer_segments sg ON c.customer_id = sg.customer_id;
