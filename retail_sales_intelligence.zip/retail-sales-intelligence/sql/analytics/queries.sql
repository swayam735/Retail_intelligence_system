-- =====================================================================
-- queries.sql
-- Advanced analytical SQL against the star schema.
-- These are the queries to walk through in interviews - they show
-- window functions, CTEs, and query design, not just SELECT *.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1) Monthly sales summary with running total and month-over-month growth
--    (window functions: SUM() OVER, LAG())
-- ---------------------------------------------------------------------
WITH monthly_sales AS (
    SELECT
        d.year,
        d.month,
        d.month_name,
        SUM(f.sales_amount) AS total_sales
    FROM fact_sales f
    JOIN dim_date d ON f.date_key = d.date_key
    GROUP BY d.year, d.month, d.month_name
)
SELECT
    year,
    month_name,
    total_sales,
    SUM(total_sales) OVER (PARTITION BY year ORDER BY month
        ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS running_total_ytd,
    LAG(total_sales, 1) OVER (ORDER BY year, month)        AS prev_month_sales,
    ROUND(
        (total_sales - LAG(total_sales, 1) OVER (ORDER BY year, month)) * 100.0
        / NULLIF(LAG(total_sales, 1) OVER (ORDER BY year, month), 0), 2
    ) AS mom_growth_pct
FROM monthly_sales
ORDER BY year, month;


-- ---------------------------------------------------------------------
-- 2) Year-over-year comparison per category
--    (self-join via CTE, no window needed - shows both approaches)
-- ---------------------------------------------------------------------
WITH yearly_category_sales AS (
    SELECT
        p.category,
        d.year,
        SUM(f.sales_amount) AS total_sales
    FROM fact_sales f
    JOIN dim_product p ON f.product_key = p.product_key
    JOIN dim_date d ON f.date_key = d.date_key
    GROUP BY p.category, d.year
)
SELECT
    curr.category,
    curr.year,
    curr.total_sales AS current_year_sales,
    prev.total_sales AS prior_year_sales,
    ROUND((curr.total_sales - prev.total_sales) * 100.0 / NULLIF(prev.total_sales, 0), 2) AS yoy_growth_pct
FROM yearly_category_sales curr
LEFT JOIN yearly_category_sales prev
    ON curr.category = prev.category AND curr.year = prev.year + 1
ORDER BY curr.category, curr.year;


-- ---------------------------------------------------------------------
-- 3) Top 3 products per store by revenue (RANK / ROW_NUMBER window fn)
-- ---------------------------------------------------------------------
WITH product_store_sales AS (
    SELECT
        s.store_name,
        p.product_name,
        SUM(f.sales_amount) AS total_sales,
        RANK() OVER (PARTITION BY s.store_name ORDER BY SUM(f.sales_amount) DESC) AS sales_rank
    FROM fact_sales f
    JOIN dim_store s ON f.store_key = s.store_key
    JOIN dim_product p ON f.product_key = p.product_key
    GROUP BY s.store_name, p.product_name
)
SELECT store_name, product_name, total_sales, sales_rank
FROM product_store_sales
WHERE sales_rank <= 3
ORDER BY store_name, sales_rank;


-- ---------------------------------------------------------------------
-- 4) Customer RFM base query (feeds the Python segmentation model,
--    also directly usable as a Power BI table)
-- ---------------------------------------------------------------------
WITH last_order_date AS (SELECT MAX(full_date) AS max_date FROM dim_date)
SELECT
    c.customer_id,
    c.customer_name,
    julianday((SELECT max_date FROM last_order_date)) - julianday(MAX(d.full_date)) AS recency_days,
    COUNT(DISTINCT f.order_id) AS frequency,
    SUM(f.sales_amount) AS monetary
FROM fact_sales f
JOIN dim_customer c ON f.customer_key = c.customer_key
JOIN dim_date d ON f.date_key = d.date_key
GROUP BY c.customer_id, c.customer_name;


-- ---------------------------------------------------------------------
-- 5) Region-level performance dashboard query
--    (multiple joins + aggregate + HAVING filter)
-- ---------------------------------------------------------------------
SELECT
    st.region,
    COUNT(DISTINCT f.order_id) AS total_orders,
    SUM(f.sales_amount) AS total_revenue,
    ROUND(AVG(f.sales_amount), 2) AS avg_order_value,
    ROUND(SUM(f.sales_amount) * 100.0 / SUM(SUM(f.sales_amount)) OVER (), 2) AS pct_of_total_revenue
FROM fact_sales f
JOIN dim_store st ON f.store_key = st.store_key
GROUP BY st.region
HAVING SUM(f.sales_amount) > 0
ORDER BY total_revenue DESC;


-- ---------------------------------------------------------------------
-- 6) Simple "stored procedure"-style reusable view
--    (SQLite has no stored procedures; this VIEW plays the same role.
--     In SQL Server this would be CREATE PROCEDURE sp_monthly_summary AS ...)
-- ---------------------------------------------------------------------
DROP VIEW IF EXISTS vw_monthly_kpi_summary;
CREATE VIEW vw_monthly_kpi_summary AS
SELECT
    d.year,
    d.month,
    d.month_name,
    COUNT(DISTINCT f.order_id) AS orders,
    SUM(f.sales_amount) AS revenue,
    ROUND(AVG(f.sales_amount), 2) AS avg_order_value,
    SUM(CASE WHEN f.promo_flag = 1 THEN f.sales_amount ELSE 0 END) AS promo_revenue
FROM fact_sales f
JOIN dim_date d ON f.date_key = d.date_key
GROUP BY d.year, d.month, d.month_name;

-- Usage:  SELECT * FROM vw_monthly_kpi_summary ORDER BY year, month;
