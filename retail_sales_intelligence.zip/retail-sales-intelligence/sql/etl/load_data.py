"""
load_data.py
------------
ETL layer: reads messy raw CSVs, cleans them, and loads them into the
star-schema SQLite warehouse defined in sql/schema/create_schema.sql.

Run order:
    1. data/generate_data.py   (creates raw CSVs)
    2. this script             (builds warehouse.db)

Usage:
    python sql/etl/load_data.py
"""

import sqlite3
import logging
from pathlib import Path

import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
log = logging.getLogger("etl")

ROOT = Path(__file__).resolve().parents[2]
RAW_DIR = ROOT / "data" / "raw"
DB_PATH = ROOT / "data" / "warehouse.db"
SCHEMA_SQL = ROOT / "sql" / "schema" / "create_schema.sql"


def build_schema(conn):
    log.info("Building schema from %s", SCHEMA_SQL)
    conn.executescript(SCHEMA_SQL.read_text())


def load_dim_date(conn, min_date, max_date):
    dates = pd.date_range(min_date, max_date, freq="D")
    df = pd.DataFrame({"full_date": dates})
    df["date_key"] = df["full_date"].dt.strftime("%Y%m%d").astype(int)
    df["day"] = df["full_date"].dt.day
    df["month"] = df["full_date"].dt.month
    df["month_name"] = df["full_date"].dt.strftime("%B")
    df["quarter"] = df["full_date"].dt.quarter
    df["year"] = df["full_date"].dt.year
    df["day_of_week"] = df["full_date"].dt.dayofweek
    df["day_name"] = df["full_date"].dt.strftime("%A")
    df["is_weekend"] = (df["day_of_week"] >= 5).astype(int)
    df.to_sql("dim_date", conn, if_exists="append", index=False)
    log.info("dim_date: %d rows loaded", len(df))


def clean_customers(df):
    before = len(df)
    df = df.drop_duplicates(subset="customer_id").copy()
    df["age"] = pd.to_numeric(df["age"], errors="coerce")
    df["age"] = df["age"].fillna(df["age"].median())

    def age_band(a):
        a = int(a)
        if a < 26:
            return "18-25"
        elif a < 36:
            return "26-35"
        elif a < 46:
            return "36-45"
        elif a < 56:
            return "46-55"
        return "56+"

    df["age_band"] = df["age"].apply(age_band)
    log.info("dim_customer: cleaned %d -> %d rows (dupes removed)", before, len(df))
    return df


def clean_products(df):
    df = df.drop_duplicates(subset="product_id").copy()
    df["margin_pct"] = ((df["unit_price"] - df["unit_cost"]) / df["unit_price"]).round(4)
    return df


def clean_stores(df):
    return df.drop_duplicates(subset="store_id").copy()


def clean_sales(df):
    before = len(df)
    df = df.drop_duplicates(subset="order_id").copy()
    # Remove bad-data rows: negative quantities (data entry errors, not true returns
    # in this synthetic set), and rows with null sales_amount we can't trust.
    df = df[df["quantity"] > 0]
    df = df.dropna(subset=["sales_amount"])
    df["order_date"] = pd.to_datetime(df["order_date"])
    df["date_key"] = df["order_date"].dt.strftime("%Y%m%d").astype(int)
    log.info("fact_sales: cleaned %d -> %d rows (bad rows dropped)", before, len(df))
    return df


def load_dimension(conn, df, table, id_col):
    df.to_sql(table, conn, if_exists="append", index=False)
    key_col = table.replace("dim_", "") + "_key"
    lookup = pd.read_sql(f"SELECT {key_col}, {id_col} FROM {table}", conn)
    return lookup


def main():
    RAW_DIR.mkdir(parents=True, exist_ok=True)
    if DB_PATH.exists():
        DB_PATH.unlink()
    conn = sqlite3.connect(DB_PATH)

    build_schema(conn)

    customers_raw = pd.read_csv(RAW_DIR / "customers.csv")
    products_raw = pd.read_csv(RAW_DIR / "products.csv")
    stores_raw = pd.read_csv(RAW_DIR / "stores.csv")
    sales_raw = pd.read_csv(RAW_DIR / "sales.csv")

    customers = clean_customers(customers_raw)
    products = clean_products(products_raw)
    stores = clean_stores(stores_raw)
    sales = clean_sales(sales_raw)

    load_dim_date(conn, sales["order_date"].min(), sales["order_date"].max())

    cust_lookup = load_dimension(
        conn, customers[["customer_id", "customer_name", "signup_date", "region", "age", "age_band"]],
        "dim_customer", "customer_id"
    )
    prod_lookup = load_dimension(
        conn, products[["product_id", "product_name", "category", "unit_cost", "unit_price", "margin_pct"]],
        "dim_product", "product_id"
    )
    store_lookup = load_dimension(
        conn, stores[["store_id", "store_name", "region", "city"]],
        "dim_store", "store_id"
    )

    fact = (
        sales.merge(cust_lookup, on="customer_id")
             .merge(prod_lookup, on="product_id")
             .merge(store_lookup, on="store_id")
    )
    fact_final = fact[[
        "order_id", "date_key", "customer_key", "product_key", "store_key",
        "quantity", "unit_price", "discount_pct", "sales_amount", "promo_flag"
    ]]
    fact_final.to_sql("fact_sales", conn, if_exists="append", index=False)
    log.info("fact_sales: %d rows loaded", len(fact_final))

    conn.commit()
    conn.close()
    log.info("Warehouse built at %s", DB_PATH)


if __name__ == "__main__":
    main()
