"""
test_pipeline.py
-----------------
Run after run_pipeline.py has been executed at least once (warehouse.db
and ml_* tables must exist).

Usage:
    pytest tests/ -v
"""

import sqlite3
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ROOT / "data" / "warehouse.db"
sys.path.append(str(ROOT / "python"))


@pytest.fixture(scope="module")
def conn():
    if not DB_PATH.exists():
        pytest.skip("warehouse.db not found - run `python run_pipeline.py` first")
    connection = sqlite3.connect(DB_PATH)
    yield connection
    connection.close()


def test_warehouse_tables_exist(conn):
    tables = {r[0] for r in conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table'"
    ).fetchall()}
    expected = {
        "fact_sales", "dim_date", "dim_customer", "dim_product", "dim_store",
        "ml_sales_forecast", "ml_customer_churn", "ml_customer_segments",
    }
    assert expected.issubset(tables)


def test_fact_sales_has_no_negative_quantity(conn):
    bad = conn.execute("SELECT COUNT(*) FROM fact_sales WHERE quantity <= 0").fetchone()[0]
    assert bad == 0


def test_fact_sales_has_no_null_sales_amount(conn):
    bad = conn.execute("SELECT COUNT(*) FROM fact_sales WHERE sales_amount IS NULL").fetchone()[0]
    assert bad == 0


def test_dim_customer_no_duplicate_ids(conn):
    total = conn.execute("SELECT COUNT(*) FROM dim_customer").fetchone()[0]
    distinct = conn.execute("SELECT COUNT(DISTINCT customer_id) FROM dim_customer").fetchone()[0]
    assert total == distinct


def test_referential_integrity_fact_to_customer(conn):
    orphans = conn.execute("""
        SELECT COUNT(*) FROM fact_sales f
        LEFT JOIN dim_customer c ON f.customer_key = c.customer_key
        WHERE c.customer_key IS NULL
    """).fetchone()[0]
    assert orphans == 0


def test_forecast_output_is_populated_and_nonnegative(conn):
    rows = conn.execute("SELECT predicted_sales FROM ml_sales_forecast").fetchall()
    assert len(rows) > 0
    assert all(r[0] >= 0 for r in rows)


def test_churn_probabilities_in_valid_range(conn):
    rows = conn.execute("SELECT churn_probability FROM ml_customer_churn").fetchall()
    assert len(rows) > 0
    assert all(0.0 <= r[0] <= 1.0 for r in rows)


def test_rfm_segments_are_labeled(conn):
    rows = conn.execute("SELECT DISTINCT rfm_segment FROM ml_customer_segments").fetchall()
    labels = {r[0] for r in rows}
    assert len(labels) > 0
    assert None not in labels


def test_monthly_kpi_view_exists_and_returns_data(conn):
    rows = conn.execute("SELECT * FROM vw_monthly_kpi_summary").fetchall()
    assert len(rows) > 0
